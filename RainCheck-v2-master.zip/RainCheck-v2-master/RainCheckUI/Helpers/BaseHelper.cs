﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RainCheckUI.Helpers
{
    public abstract class BaseHelper
    {
    }
}
